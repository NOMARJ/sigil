# sigilsec.ai — Development Guide

## Project Overview
Marketing landing page and AEO-optimized blog for Sigil (sigilsec.ai). Built with Next.js, Flowbite Pro, and Tailwind CSS. Blog powered by cakewalk.ai headless CMS.

## Quick Start
```bash
npm install
cp .env.example .env.local   # Fill in cakewalk.ai keys
npm run dev                   # http://localhost:3000
```

## Architecture
- **Framework:** Next.js 14+ (App Router) with SSG/ISR
- **UI Components:** Flowbite Pro + Flowbite React (Tailwind CSS)
- **Blog CMS:** cakewalk.ai (@cakewalk-ai/api SDK)
- **Analytics:** Plausible or PostHog (privacy-respecting)

## Key Directories
```
src/app/           - Next.js App Router pages
src/components/    - Flowbite Pro-based React components
src/lib/           - Utilities (cakewalk client, analytics, constants)
src/content/       - Static copy and content
src/types/         - TypeScript type definitions
docs/              - PRD and documentation
public/            - Static assets (favicon, OG images, robots.txt)
```

## Blog Integration
Blog content is managed in cakewalk.ai and fetched at build time via ISR.
- `src/lib/cakewalk.ts` — API client
- `src/app/blog/` — Blog routes
- `src/app/api/revalidate/` — On-demand ISR webhook endpoint

## Commands
```bash
npm run dev         # Development server
npm run build       # Production build
npm run lint        # ESLint
npm run type-check  # TypeScript checking
```

## PRD
See `docs/prd-landing-page.md` for full product requirements.
