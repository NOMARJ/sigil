export function Navbar() {
  // TODO: Implement with Flowbite Pro marketing navbar (mega-menu variant)
  // - Sigil logo/wordmark linking to top
  // - Nav links: Features, How It Works, Integrations, Pricing, Blog, Docs
  // - GitHub link with live star count badge
  // - "Get Started" CTA button
  // - Mobile hamburger menu
  return <nav id="navbar" />;
}
