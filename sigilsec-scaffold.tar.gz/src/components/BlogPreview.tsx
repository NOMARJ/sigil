import { blog } from "@/lib/cakewalk";

export async function BlogPreview() {
  // TODO: Implement with Flowbite Pro blog card grid (3-col)
  // - Headline: "From the Sigil blog"
  // - 3 latest posts from cakewalk.ai
  // - Each card: title, date, excerpt, category badge, read time
  // - "Read all posts" CTA linking to /blog

  let posts: Awaited<ReturnType<typeof blog.getPosts>>["posts"] = [];
  try {
    const result = await blog.getPosts({ status: "published", limit: 3 });
    posts = result.posts;
  } catch {
    // Blog not configured yet — render empty
  }

  if (posts.length === 0) return null;

  return <section id="blog-preview" />;
}
