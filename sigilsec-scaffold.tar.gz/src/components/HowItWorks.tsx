export function HowItWorks() {
  // TODO: Implement with Flowbite Pro timeline/steps section
  // - Headline: "Three steps. Full protection."
  // - 3-step horizontal flow: Run a command -> Sigil scans -> You decide
  // - Terminal replay/screenshot below steps
  return <section id="how-it-works" />;
}
