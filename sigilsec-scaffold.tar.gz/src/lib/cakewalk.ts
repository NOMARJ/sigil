import { AEO } from "@cakewalk-ai/api";

export const blog = new AEO.BlogClient({
  apiKey: process.env.CAKEWALK_API_KEY!,
  projectId: process.env.CAKEWALK_PROJECT_ID!,
  options: { cacheTtl: 600 },
});
