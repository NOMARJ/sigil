type EventName =
  | "install_copy"
  | "cta_click"
  | "section_view"
  | "github_click"
  | "pricing_view"
  | "pricing_cta_click"
  | "docs_click"
  | "scroll_depth"
  | "blog_view"
  | "blog_listing_view"
  | "blog_cta_click"
  | "blog_share";

type EventProps = Record<string, string | number>;

export function trackEvent(name: EventName, props?: EventProps) {
  // Plausible
  if (typeof window !== "undefined" && "plausible" in window) {
    (window as Record<string, unknown>).plausible?.(name, {
      props,
    });
  }
}
