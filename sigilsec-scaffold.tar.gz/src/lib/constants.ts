export const SITE = {
  name: "Sigil",
  tagline: "A protective mark for every line of code.",
  description:
    "Automated security auditing for AI agent code. Quarantine-first workflow.",
  url: process.env.NEXT_PUBLIC_SITE_URL || "https://sigilsec.ai",
  github: "https://github.com/NOMARJ/sigil",
  org: "NOMARK",
  orgUrl: "https://nomark.ai",
} as const;

export const INSTALL_COMMANDS = {
  curl: "curl -sSL https://sigilsec.ai/install.sh | sh",
  brew: "brew install nomarj/tap/sigil",
  npm: "npm install -g @nomarj/sigil",
} as const;

export const NAV_LINKS = [
  { label: "Features", href: "#features" },
  { label: "How It Works", href: "#how-it-works" },
  { label: "Integrations", href: "#integrations" },
  { label: "Pricing", href: "#pricing" },
  { label: "Blog", href: "/blog" },
  { label: "Docs", href: "/docs", external: true },
] as const;
