import type { Metadata } from "next";
import { blog } from "@/lib/cakewalk";

export const metadata: Metadata = {
  title: "Blog — Sigil",
  description:
    "Security research, threat intelligence, and guides for protecting AI agent code and MCP servers.",
};

export const revalidate = 300;

export default async function BlogIndex({
  searchParams,
}: {
  searchParams: { category?: string; page?: string };
}) {
  // TODO: Implement with Flowbite Pro blog grid page
  // - Category filter tabs
  // - Blog card grid
  // - Pagination

  const page = Number(searchParams.page) || 1;
  const limit = 12;
  const offset = (page - 1) * limit;

  const { posts, pagination } = await blog.getPosts({
    status: "published",
    category: searchParams.category,
    limit,
    offset,
  });

  return (
    <main>
      {/* Blog listing — Flowbite Pro blog card grid */}
      <pre>{JSON.stringify({ posts: posts.length, pagination }, null, 2)}</pre>
    </main>
  );
}
