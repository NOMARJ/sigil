import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { blog } from "@/lib/cakewalk";

export const revalidate = 300;

export async function generateStaticParams() {
  const { posts } = await blog.getPosts({ status: "published", limit: 100 });
  return posts.map((post) => ({ slug: post.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: { slug: string };
}): Promise<Metadata> {
  const post = await blog.getPostBySlug(params.slug);
  if (!post) return {};

  return {
    title: `${post.meta_title || post.title} — Sigil Blog`,
    description: post.meta_description || post.excerpt || undefined,
    openGraph: {
      title: post.meta_title || post.title,
      description: post.meta_description || post.excerpt || undefined,
      type: "article",
      publishedTime: post.published_at || undefined,
      modifiedTime: post.updated_at || undefined,
      images: post.featured_image_url ? [post.featured_image_url] : [],
    },
  };
}

export default async function BlogPost({
  params,
}: {
  params: { slug: string };
}) {
  const post = await blog.getPostBySlug(params.slug);
  if (!post) notFound();

  return (
    <main>
      {/* TODO: Implement with Flowbite Pro article page layout */}
      {/* - TOC sidebar, author card, related posts, FAQ accordion */}
      <article>
        <h1>{post.title}</h1>
        {post.author && <p>By {post.author.name}</p>}
        {post.body_html && (
          <div dangerouslySetInnerHTML={{ __html: post.body_html }} />
        )}
      </article>

      {/* JSON-LD schemas from cakewalk.ai */}
      {post.schema_json_ld?.map((schema, i) => (
        <script
          key={i}
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
        />
      ))}
    </main>
  );
}
