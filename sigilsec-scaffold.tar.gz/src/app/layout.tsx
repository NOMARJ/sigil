import type { Metadata } from "next";
import { ThemeModeScript } from "flowbite-react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Sigil — Automated Security Auditing for AI Agent Code",
  description:
    "Quarantine and scan every repo, package, and MCP server before it runs. Free, open source CLI with six-phase analysis. By NOMARK.",
  metadataBase: new URL(
    process.env.NEXT_PUBLIC_SITE_URL || "https://sigilsec.ai",
  ),
  openGraph: {
    title: "Sigil — Automated Security Auditing for AI Agent Code",
    description:
      "Quarantine and scan every repo, package, and MCP server before it runs. Free, open source CLI with six-phase analysis.",
    url: "https://sigilsec.ai",
    siteName: "Sigil",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Sigil — Automated Security Auditing for AI Agent Code",
    description:
      "Quarantine and scan every repo, package, and MCP server before it runs.",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <head>
        <ThemeModeScript mode="dark" />
      </head>
      <body className="antialiased">{children}</body>
    </html>
  );
}
