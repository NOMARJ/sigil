import { Navbar } from "@/components/Navbar";
import { Hero } from "@/components/Hero";
import { ProblemStatement } from "@/components/ProblemStatement";
import { HowItWorks } from "@/components/HowItWorks";
import { ScanPhases } from "@/components/ScanPhases";
import { Integrations } from "@/components/Integrations";
import { Comparison } from "@/components/Comparison";
import { Pricing } from "@/components/Pricing";
import { SocialProof } from "@/components/SocialProof";
import { DevExperience } from "@/components/DevExperience";
import { BlogPreview } from "@/components/BlogPreview";
import { InstallCTA } from "@/components/InstallCTA";
import { Footer } from "@/components/Footer";

export default function Home() {
  return (
    <>
      <Navbar />
      <main>
        <Hero />
        <ProblemStatement />
        <HowItWorks />
        <ScanPhases />
        <Integrations />
        <Comparison />
        <Pricing />
        <SocialProof />
        <DevExperience />
        <BlogPreview />
        <InstallCTA />
      </main>
      <Footer />
    </>
  );
}
