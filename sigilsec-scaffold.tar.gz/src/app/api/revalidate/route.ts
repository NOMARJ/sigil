import { revalidatePath } from "next/cache";
import { NextRequest } from "next/server";
import { blog } from "@/lib/cakewalk";

export async function POST(request: NextRequest) {
  const secret = request.headers.get("x-webhook-secret");
  if (secret !== process.env.REVALIDATION_SECRET) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  const body = await request.json();
  const slug: string | undefined = body.slug;

  // Clear cakewalk.ai SDK cache
  blog.clearCache();

  // Revalidate blog routes
  revalidatePath("/blog");
  if (slug) revalidatePath(`/blog/${slug}`);

  // Also revalidate homepage (blog preview section)
  revalidatePath("/");

  return Response.json({ revalidated: true, slug: slug || null });
}
